package com.capgemini.hbms.dao;

import java.util.ArrayList;
import java.util.Date;

import com.capgemini.hbms.bean.HBMSBookingBean;
import com.capgemini.hbms.bean.HBMSGuestBean;
import com.capgemini.hbms.bean.HBMSHotelBean;
import com.capgemini.hbms.bean.HBMSRoomBean;
import com.capgemini.hbms.bean.HBMSUserBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IHBMSDao {

	boolean isValidLoginDetails(String username, String password) throws HBMSException;

	boolean registerUser(HBMSUserBean userBean) throws HBMSException;

	ArrayList<HBMSHotelBean> getHotelList() throws HBMSException;

	ArrayList<HBMSRoomBean> getRoomList(String id) throws HBMSException;

	String getUserId(String username, String password) throws HBMSException;

	float getRoomAmount(String roomId) throws HBMSException;

	String addBookingDetails(HBMSBookingBean booking) throws HBMSException;

	HBMSBookingBean getBookingDetails(String bookingId) throws HBMSException;

	String addHotelDetails(HBMSHotelBean bean) throws HBMSException;

	boolean isValidHotelId(String hotelID) throws HBMSException;

	ArrayList<HBMSBookingBean> getBookingsOfHotel(String hotelID) throws HBMSException;

	void deleteHotel(String hotelID) throws HBMSException;

	boolean isValidRoomId(String roomID) throws HBMSException;

	void deleteRoom(String roomID) throws HBMSException;

	ArrayList<HBMSGuestBean> getGuestListOfHotel(String hotelID) throws HBMSException;

	ArrayList<HBMSBookingBean> getBookingsOfSpecifiedDate(Date bookingDate) throws HBMSException;

	void checkAvaialbilityStatus() throws HBMSException;

	void changeRoomStatus(String roomid) throws HBMSException;

	boolean isValidUserName(String userName) throws HBMSException;



	void modifyRating(String hotelID,int rating) throws HBMSException;

}
